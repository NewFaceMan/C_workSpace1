#include <stdio.h>
int main(int argc, char const *argv[])
{
    char ch; int i;
    scanf("%c", &ch);
    for (int i = 'a'; i <= ch; i++)
    {
        if (ch != 'a' && ch != 'e' && ch!='i', ch != 'o', ch != 'u')
        {
            printf("%c", ch);
        }
        
    }
    
    return 0;
}
